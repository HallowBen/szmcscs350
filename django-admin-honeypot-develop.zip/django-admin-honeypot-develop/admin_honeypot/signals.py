from django import dispatch

honeypot = dispatch.Signal()
