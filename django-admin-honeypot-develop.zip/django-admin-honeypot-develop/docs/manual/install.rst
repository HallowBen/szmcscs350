============
Installation
============

Requirements
============

* Python 3.5+
* Django 2.2+

Install
=======

django-admin-honeypot is on `PyPI`_ and can be installed with `pip`_:

::

    pip install django-admin-honeypot

.. _PyPI: http://pypi.python.org/
.. _pip: http://www.pip-installer.org/
